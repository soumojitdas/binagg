"""Tests for the BinAgg package."""
